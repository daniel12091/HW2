#include <stdlib.h>
#include <stdio.h>

#include "03-circle.h"

void circle_draw()
{
	shape_draw();
    printf("circle_draw()\n");
}
