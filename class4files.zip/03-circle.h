#ifndef CIRCLE_H
#define CIRCLE_H

#include "03-shape.h"

void circle_draw();

#endif