//#ifndef SHAPE_H
//#define SHAPE_H

void shape_draw();

//#endif