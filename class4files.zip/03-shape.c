#include <stdlib.h>
#include <stdio.h>

#include "03-shape.h"

void shape_draw()
{
    printf("shape_draw()\n");
}
