#include <stdlib.h>
#include <stdio.h>

#include "03-shape.h"
#include "03-circle.h"

int main()
{
	circle_draw();
    return 0;
}
